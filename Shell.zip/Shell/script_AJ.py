#!/usr/bin/env python
# coding: utf-8

# In[3]:


import time

c = str(input('\nwhat is the size of shehjade? \n'))
if c == '6':
    print('\nHmmmmm!!!! Stop Blushing! You are Right\n')
    time.sleep(4)
else:
    print('\nYou need more practice with AJ! Wrong Answer\n')
    time.sleep(4)
    
print('\n!!Lets go for next question\n')
time.sleep(6)
d = str(input('\nWhat is the size of Malai? \n'))
if d  == '32':
    print('\nWohhhhhhhh!!! Kick Kick Kick Basli\n')
    time.sleep(4)
    print('HIHI!!!')
else:
    print('\nSorry Wrong Answer!! You need to see again :)\n')
    time.sleep(4)
    print('So Sad!!!')


# In[ ]:





# In[ ]:





# In[ ]:




